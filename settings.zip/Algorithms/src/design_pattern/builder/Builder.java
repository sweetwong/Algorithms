package design_pattern.builder;

// todo 不妨把23种设计模式都写出对应的模板或者例子方法, 就参考设计模式之禅, 记住, 实现的时候不要抄, 要理解着写
class Builder {
}
