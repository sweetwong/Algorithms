package design_pattern.singleton;

public enum Enum {

    INSTANCE;

}
