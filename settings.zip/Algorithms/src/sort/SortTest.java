package sort;

public class SortTest {

    public static void test(Runnable runnable) {

    }

}
