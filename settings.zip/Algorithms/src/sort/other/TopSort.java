package sort.other;

import java.util.List;

/**
 * 拓扑排序 todo
 */
public class TopSort {

    public static void sort(List<List<Integer>> adj) {

    }
}
