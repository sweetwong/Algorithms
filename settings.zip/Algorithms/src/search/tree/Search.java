package search.tree;

/**
 * @see util.tree.TreeUtils 几乎所有树相关的操作都写在这里了
 */
class Search {
}
