package search.graph;

import algs4.DepthFirstSearch;
import algs4.DirectedDFS;

/**
 * @see DepthFirstSearch 无向图的深度优先搜索
 * @see DirectedDFS 有向图的深度优先搜索
 */
class Search {
}
