package javas.question.method_dispatch;

class Parent {

    public void getName() {
        System.out.println("Parent");
    }
}
