package javas.reflect.dynamic_proxy;

interface Download {

    int downloadVideo();

    int downloadAudio();
}
