package javas.string;

class UnicodeDemo {

    public static void main(String[] args) {
        char c = 'ｎ';
        System.out.println((int) c);
    }
}
