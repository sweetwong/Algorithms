package util.graph;

/**
 * todo
 */
class Dijkstra {
}
