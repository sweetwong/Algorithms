package util.string;

/**
 * Boyer-Moore
 */
class BM {
}
