package util.string;

/**
 * todo
 */
class KMP {
}
