package util.linked_list;

/**
 * 链表的节点类
 */
public class ListNode {

    public int val;
    public ListNode next;

    public ListNode(int x) {
        val = x;
    }
}

