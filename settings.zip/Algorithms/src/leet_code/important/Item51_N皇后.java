package leet_code.important;

import java.util.ArrayList;
import java.util.List;

/**
 * @see classical.NQueens
 */
class Item51_N皇后 {
}
