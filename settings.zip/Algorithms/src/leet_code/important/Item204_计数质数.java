package leet_code.important;

/**
 * @see classical.CountPrimes
 */
class Item204_计数质数 {


}
