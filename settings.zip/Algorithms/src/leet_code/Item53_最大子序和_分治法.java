package leet_code;

class Item53_最大子序和_分治法 {

    public static void main(String[] args) {
        int[] nums = {-2, 1, -3, 4, -1, 2, 1, -5, 4};
        int i = maxSubArray(nums);
    }

    /**
     * 贪心法
     */
    public static int maxSubArray(int[] nums) {
        return 0;
    }


}
