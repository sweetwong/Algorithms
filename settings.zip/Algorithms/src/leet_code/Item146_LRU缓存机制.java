package leet_code;

/**
 * @see classical.LRUCache
 */
class Item146_LRU缓存机制 {

}
