package leet_code;

/**
 * 这个strStr其实就是Java的indexOf, 自己手动实现一下
 *
 */
class Item28_实现strStr {

    public int strStr(String haystack, String needle) {
        return haystack.indexOf(needle);
    }


}
