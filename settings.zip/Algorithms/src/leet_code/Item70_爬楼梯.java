package leet_code;

/**
 * @see classical.ClimbStairs 爬楼梯
 */
class Item70_爬楼梯 {
}
